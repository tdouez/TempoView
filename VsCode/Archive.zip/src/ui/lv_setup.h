#pragma once

void lv_begin();
void lv_handler();